package com.Crud;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

	public void addStudent(Student student) {
		String sql = "INSERT INTO `student`.`student_details` ( `student_rollno`, `student_name`, `student_department`) VALUES (?,?,?)";
		try (Connection con = DBConnection.getConnection(); PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setInt(1, student.getRollno());
			stmt.setString(2, student.getName());
			stmt.setString(3, student.getDepartment());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Student> getAllStudents() {
		List<Student> list = new ArrayList<>();
		String sql = "SELECT * FROM student_details";
		try (Connection con = DBConnection.getConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
list.add(new Student(rs.getInt("student_rollno"), rs.getString("student_name"), rs.getString("student_department")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void updateStudent(Student student) {
		String sql = "UPDATE `student`.`student_details` SET `student_name` = ?, `student_department` = ? WHERE (`student_rollno` = ?)";
		try (Connection con = DBConnection.getConnection(); PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setString(1, student.getName());
			stmt.setString(2, student.getDepartment());
			stmt.setInt(3, student.getRollno());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void deleteStudent(int id) {
		String sql = "DELETE FROM student_details WHERE student_rollno=?";
		try (Connection con = DBConnection.getConnection(); PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
