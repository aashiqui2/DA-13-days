package com.Crud;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter RollNo: ");
                    int Rollno = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String Name = sc.nextLine();
                    System.out.print("Enter Department: ");
                    String Department = sc.nextLine();
                    dao.addStudent(new Student(Rollno, Name, Department));
                    break;
                case 2:
                    List<Student> students = dao.getAllStudents();
                    for (Student s : students) {
                        System.out.println(s.getRollno() + " " + s.getName() + " " + s.getDepartment());
                    }
                    break;
                case 3:
                    System.out.print("Enter student RollNo to update: ");
                    System.out.print("Enter RollNo: ");
                    Rollno = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    Name = sc.nextLine();
                    System.out.print("Enter Department: ");
                    Department = sc.nextLine();
                    dao.updateStudent(new Student(Rollno,Name,Department));
                    break;
                case 4:
                    System.out.print("Enter student RollNo to delete: ");
                    int RollNo = sc.nextInt();
                    dao.deleteStudent(RollNo);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
            }

        } while (choice != 5);
        sc.close();
    }
}
