package com.JdbcBasics;
import java.sql.*;

public class JdbcDemo2 {
	public static void main(String[] args) throws SQLException {
		String url="jdbc:mysql://localhost:3306/test";
		String uname="root";
		String pass="aashiqui";
		Connection con=DriverManager.getConnection(url,uname,pass);
		String query="INSERT INTO `studentdetails` (`Sno`, `Name`,`Email`,`Mobile`) VALUES (?,?,?,?);";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1,6);
		ps.setString(2,"Aashiqui");
		ps.setString(3,"aashiqui@CampusConnect.com");
		ps.setInt(4,87485743);
		int count=ps.executeUpdate();
		System.out.println(count);
		ps.close();
		con.close();
		
	}
}
