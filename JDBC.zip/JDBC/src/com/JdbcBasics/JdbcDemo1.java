package com.JdbcBasics;
import java.sql.*;
public class JdbcDemo1 {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		String url="jdbc:mysql://localhost:3306/test";
		String uname="root";
		String pass="";
		Connection con=DriverManager.getConnection(url,uname,pass);
		String query="INSERT INTO `studentdetails` (`Sno`, `Name`, `Email`, `Mobile`) VALUES ('7', 'Niki', 'Niki@CampusConnect.com', '43987646');";
//		Class.forName("com.mysql.cj.jdbc.Driver");
		Statement st=con.createStatement();
		int count=st.executeUpdate(query);
		System.out.println(count +" rows affected");
		st.close();
		con.close();
	}
}
