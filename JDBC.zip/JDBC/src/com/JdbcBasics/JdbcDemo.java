package com.JdbcBasics;
import java.sql.*;
public class JdbcDemo {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		String url="jdbc:mysql://localhost:3306/test";
		String uname="root";
		String pass="";
//Not needed in the new version of java
//		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,uname,pass);
		String query="select * from StudentDetails";
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(query);
		while (rs.next()) {
            int id = rs.getInt("Sno");
            String Name = rs.getString("Name");
            String Email = rs.getString("email");
            int Mobile = rs.getInt("Mobile");
            System.out.println("Sno: " + id + ", Name: " + Name +", Email: "+Email+" Mobile "+ Mobile);
           
        }
		st.close();
		con.close();

	}
}
